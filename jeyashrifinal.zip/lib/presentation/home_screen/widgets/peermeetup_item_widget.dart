import '../models/peermeetup_item_model.dart';
import 'package:flutter/material.dart';
import 'package:thameeml_ansari_u_s_application3/core/app_export.dart';

// ignore: must_be_immutable
class PeermeetupItemWidget extends StatelessWidget {
  PeermeetupItemWidget(
    this.peermeetupItemModelObj, {
    Key? key,
  }) : super(
          key: key,
        );

  PeermeetupItemModel peermeetupItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: Card(
        clipBehavior: Clip.antiAlias,
        elevation: 0,
        margin: EdgeInsets.all(0),
        color: appTheme.pink50,
        shape: RoundedRectangleBorder(
          side: BorderSide(
            color: appTheme.deepPurple50,
            width: 1.h,
          ),
          borderRadius: BorderRadiusStyle.roundedBorder20,
        ),
        child: Container(
          height: 157.v,
          width: 325.h,
          padding: EdgeInsets.symmetric(
            horizontal: 22.h,
            vertical: 14.v,
          ),
          decoration: AppDecoration.outlineDeepPurple.copyWith(
            borderRadius: BorderRadiusStyle.roundedBorder20,
          ),
          child: Stack(
            alignment: Alignment.topLeft,
            children: [
              Align(
                alignment: Alignment.bottomRight,
                child: Container(
                  height: 41.v,
                  width: 39.h,
                  margin: EdgeInsets.only(bottom: 23.v),
                  child: Stack(
                    alignment: Alignment.bottomRight,
                    children: [
                      CustomImageView(
                        imagePath: peermeetupItemModelObj?.image1,
                        height: 41.v,
                        width: 36.h,
                        alignment: Alignment.centerLeft,
                      ),
                      CustomImageView(
                        imagePath: peermeetupItemModelObj?.image2,
                        height: 15.adaptSize,
                        width: 15.adaptSize,
                        alignment: Alignment.bottomRight,
                        margin: EdgeInsets.only(bottom: 4.v),
                      ),
                    ],
                  ),
                ),
              ),
              Align(
                alignment: Alignment.topLeft,
                child: Container(
                  height: 115.v,
                  width: 254.h,
                  margin: EdgeInsets.only(left: 2.h),
                  child: Stack(
                    alignment: Alignment.topRight,
                    children: [
                      CustomImageView(
                        imagePath: peermeetupItemModelObj?.image3,
                        height: 41.v,
                        width: 36.h,
                        alignment: Alignment.bottomRight,
                        margin: EdgeInsets.only(
                          right: 23.h,
                          bottom: 13.v,
                        ),
                      ),
                      CustomImageView(
                        imagePath: peermeetupItemModelObj?.image4,
                        height: 24.v,
                        width: 40.h,
                        alignment: Alignment.topRight,
                        margin: EdgeInsets.only(top: 32.v),
                      ),
                      CustomImageView(
                        imagePath: peermeetupItemModelObj?.image5,
                        height: 15.adaptSize,
                        width: 15.adaptSize,
                        alignment: Alignment.topRight,
                        margin: EdgeInsets.only(
                          top: 22.v,
                          right: 12.h,
                        ),
                      ),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: SizedBox(
                          height: 115.v,
                          width: 207.h,
                          child: Stack(
                            alignment: Alignment.bottomRight,
                            children: [
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      peermeetupItemModelObj.text1!,
                                      style: theme.textTheme.headlineSmall,
                                    ),
                                    SizedBox(height: 4.v),
                                    SizedBox(
                                      width: 173.h,
                                      child: Text(
                                        peermeetupItemModelObj.text2!,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: CustomTextStyles.bodyMediumLight,
                                      ),
                                    ),
                                    SizedBox(height: 13.v),
                                    Row(
                                      children: [
                                        Text(
                                          peermeetupItemModelObj.text3!,
                                          style: CustomTextStyles
                                              .titleLargePrimaryContainer,
                                        ),
                                        CustomImageView(
                                          imagePath:
                                              peermeetupItemModelObj?.image6,
                                          height: 15.adaptSize,
                                          width: 15.adaptSize,
                                          margin: EdgeInsets.only(
                                            left: 10.h,
                                            top: 4.v,
                                            bottom: 4.v,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              CustomImageView(
                                imagePath: peermeetupItemModelObj?.image7,
                                height: 15.adaptSize,
                                width: 15.adaptSize,
                                alignment: Alignment.bottomRight,
                                margin: EdgeInsets.only(bottom: 18.v),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
