import '../models/happycomponent_item_model.dart';
import 'package:flutter/material.dart';
import 'package:thameeml_ansari_u_s_application3/core/app_export.dart';

// ignore: must_be_immutable
class HappycomponentItemWidget extends StatelessWidget {
  HappycomponentItemWidget(
    this.happycomponentItemModelObj, {
    Key? key,
  }) : super(
          key: key,
        );

  HappycomponentItemModel happycomponentItemModelObj;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 69.h,
      child: Column(
        children: [
          Container(
            height: 72.v,
            width: 69.h,
            padding: EdgeInsets.symmetric(
              horizontal: 15.h,
              vertical: 16.v,
            ),
            decoration: AppDecoration.fillPrimaryContainer.copyWith(
              borderRadius: BorderRadiusStyle.roundedBorder20,
            ),
            child: CustomImageView(
              imagePath: happycomponentItemModelObj?.happyImage,
              height: 39.adaptSize,
              width: 39.adaptSize,
              alignment: Alignment.center,
            ),
          ),
          SizedBox(height: 7.v),
          Text(
            happycomponentItemModelObj.happyText!,
            style: theme.textTheme.bodyMedium,
          ),
        ],
      ),
    );
  }
}
