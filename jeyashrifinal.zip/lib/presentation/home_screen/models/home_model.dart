import '../../../core/app_export.dart';
import 'happycomponent_item_model.dart';
import 'peermeetup_item_model.dart';

class HomeModel {
  List<HappycomponentItemModel> happycomponentItemList = [
    HappycomponentItemModel(
        happyImage: ImageConstant.imgThumbsUp, happyText: "Happy"),
    HappycomponentItemModel(
        happyImage: ImageConstant.imgUser, happyText: "Calm"),
    HappycomponentItemModel(
        happyImage: ImageConstant.imgRelax, happyText: "Relax"),
    HappycomponentItemModel(happyText: "Focus")
  ];

  List<PeermeetupItemModel> peermeetupItemList = [
    PeermeetupItemModel(
        image1: ImageConstant.imgVectorPrimarycontainer,
        image2: ImageConstant.imgVectorPrimarycontainer15x15,
        image3: ImageConstant.imgVectorPrimarycontainer41x36,
        image4: ImageConstant.imgVectorPrimarycontainer24x40,
        image5: ImageConstant.imgVector15x15,
        text1: "Peer Group Meetup",
        text2: "Let’s open up to the  thing that matters amoung the people ",
        text3: "Join Now",
        image6: ImageConstant.imgWarning,
        image7: ImageConstant.imgVector1)
  ];
}
