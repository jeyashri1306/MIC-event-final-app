import '../../../core/app_export.dart';

/// This class is used in the [happycomponent_item_widget] screen.
class HappycomponentItemModel {
  HappycomponentItemModel({
    this.happyImage,
    this.happyText,
    this.id,
  }) {
    happyImage = happyImage ?? ImageConstant.imgThumbsUp;
    happyText = happyText ?? "Happy";
    id = id ?? "";
  }

  String? happyImage;

  String? happyText;

  String? id;
}
