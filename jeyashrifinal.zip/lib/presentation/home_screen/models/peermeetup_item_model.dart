import '../../../core/app_export.dart';

/// This class is used in the [peermeetup_item_widget] screen.
class PeermeetupItemModel {
  PeermeetupItemModel({
    this.image1,
    this.image2,
    this.image3,
    this.image4,
    this.image5,
    this.text1,
    this.text2,
    this.text3,
    this.image6,
    this.image7,
    this.id,
  }) {
    image1 = image1 ?? ImageConstant.imgVectorPrimarycontainer;
    image2 = image2 ?? ImageConstant.imgVectorPrimarycontainer15x15;
    image3 = image3 ?? ImageConstant.imgVectorPrimarycontainer41x36;
    image4 = image4 ?? ImageConstant.imgVectorPrimarycontainer24x40;
    image5 = image5 ?? ImageConstant.imgVector15x15;
    text1 = text1 ?? "Peer Group Meetup";
    text2 =
        text2 ?? "Let’s open up to the  thing that matters amoung the people ";
    text3 = text3 ?? "Join Now";
    image6 = image6 ?? ImageConstant.imgWarning;
    image7 = image7 ?? ImageConstant.imgVector1;
    id = id ?? "";
  }

  String? image1;

  String? image2;

  String? image3;

  String? image4;

  String? image5;

  String? text1;

  String? text2;

  String? text3;

  String? image6;

  String? image7;

  String? id;
}
