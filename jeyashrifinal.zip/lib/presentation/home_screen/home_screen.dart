import '../home_screen/widgets/happycomponent_item_widget.dart';
import '../home_screen/widgets/peermeetup_item_widget.dart';
import 'models/happycomponent_item_model.dart';
import 'models/home_model.dart';
import 'models/peermeetup_item_model.dart';
import 'package:flutter/material.dart';
import 'package:thameeml_ansari_u_s_application3/core/app_export.dart';
import 'package:thameeml_ansari_u_s_application3/widgets/app_bar/appbar_leading_image.dart';
import 'package:thameeml_ansari_u_s_application3/widgets/app_bar/appbar_trailing_circleimage.dart';
import 'package:thameeml_ansari_u_s_application3/widgets/app_bar/custom_app_bar.dart';
import 'package:thameeml_ansari_u_s_application3/widgets/custom_bottom_bar.dart';
import 'provider/home_provider.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key})
      : super(
          key: key,
        );

  @override
  HomeScreenState createState() => HomeScreenState();
  static Widget builder(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => HomeProvider(),
      child: HomeScreen(),
    );
  }
}

class HomeScreenState extends State<HomeScreen> {
  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _buildAppBar(context),
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 19.v),
              Padding(
                padding: EdgeInsets.only(left: 24.h),
                child: RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: "lbl_welcome_back".tr,
                        style: CustomTextStyles.headlineLargeRegular,
                      ),
                      TextSpan(
                        text: "lbl".tr,
                        style: theme.textTheme.headlineLarge,
                      ),
                      TextSpan(
                        text: "lbl_sarina".tr,
                        style: CustomTextStyles.headlineLargeBold,
                      ),
                    ],
                  ),
                  textAlign: TextAlign.left,
                ),
              ),
              SizedBox(height: 31.v),
              _buildHappyComponent(context),
              SizedBox(height: 36.v),
              Padding(
                padding: EdgeInsets.only(left: 24.h),
                child: Text(
                  "lbl_today_s_task".tr,
                  style: theme.textTheme.titleLarge,
                ),
              ),
              SizedBox(height: 15.v),
              _buildPeerMeetup(context),
            ],
          ),
        ),
        bottomNavigationBar: _buildBottomBar(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 47.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowDown,
        margin: EdgeInsets.only(
          left: 25.h,
          top: 19.v,
          bottom: 18.v,
        ),
      ),
      actions: [
        AppbarTrailingCircleimage(
          imagePath: ImageConstant.imgEllipse2,
          margin: EdgeInsets.symmetric(
            horizontal: 24.h,
            vertical: 10.v,
          ),
        ),
      ],
    );
  }

  /// Section Widget
  Widget _buildHappyComponent(BuildContext context) {
    return Align(
      alignment: Alignment.centerRight,
      child: Padding(
        padding: EdgeInsets.only(left: 24.h),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "msg_how_are_you_feeling".tr,
              style: theme.textTheme.titleLarge,
            ),
            SizedBox(height: 21.v),
            SizedBox(
              height: 98.v,
              child: Consumer<HomeProvider>(
                builder: (context, provider, child) {
                  return ListView.separated(
                    scrollDirection: Axis.horizontal,
                    separatorBuilder: (
                      context,
                      index,
                    ) {
                      return SizedBox(
                        width: 33.h,
                      );
                    },
                    itemCount:
                        provider.homeModelObj.happycomponentItemList.length,
                    itemBuilder: (context, index) {
                      HappycomponentItemModel model =
                          provider.homeModelObj.happycomponentItemList[index];
                      return HappycomponentItemWidget(
                        model,
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildPeerMeetup(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 24.h),
        child: Consumer<HomeProvider>(
          builder: (context, provider, child) {
            return ListView.separated(
              physics: NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              separatorBuilder: (
                context,
                index,
              ) {
                return SizedBox(
                  height: 27.v,
                );
              },
              itemCount: provider.homeModelObj.peermeetupItemList.length,
              itemBuilder: (context, index) {
                PeermeetupItemModel model =
                    provider.homeModelObj.peermeetupItemList[index];
                return PeermeetupItemWidget(
                  model,
                );
              },
            );
          },
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {},
    );
  }
}
