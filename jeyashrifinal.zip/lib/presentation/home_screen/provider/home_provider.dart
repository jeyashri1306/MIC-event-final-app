import 'package:flutter/material.dart';
import 'package:thameeml_ansari_u_s_application3/core/app_export.dart';
import 'package:thameeml_ansari_u_s_application3/presentation/home_screen/models/home_model.dart';
import '../models/happycomponent_item_model.dart';
import '../models/peermeetup_item_model.dart';

/// A provider class for the HomeScreen.
///
/// This provider manages the state of the HomeScreen, including the
/// current homeModelObj

// ignore_for_file: must_be_immutable
class HomeProvider extends ChangeNotifier {
  HomeModel homeModelObj = HomeModel();

  @override
  void dispose() {
    super.dispose();
  }
}
