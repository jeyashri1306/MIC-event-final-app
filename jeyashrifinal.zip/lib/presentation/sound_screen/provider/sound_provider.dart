import 'package:flutter/material.dart';
import 'package:thameeml_ansari_u_s_application3/core/app_export.dart';
import 'package:thameeml_ansari_u_s_application3/presentation/sound_screen/models/sound_model.dart';

/// A provider class for the SoundScreen.
///
/// This provider manages the state of the SoundScreen, including the
/// current soundModelObj
class SoundProvider extends ChangeNotifier {
  SoundModel soundModelObj = SoundModel();

  @override
  void dispose() {
    super.dispose();
  }
}
