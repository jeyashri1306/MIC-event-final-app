import 'models/sound_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;
import 'package:thameeml_ansari_u_s_application3/core/app_export.dart';
import 'package:thameeml_ansari_u_s_application3/widgets/app_bar/appbar_leading_image.dart';
import 'package:thameeml_ansari_u_s_application3/widgets/app_bar/appbar_trailing_image.dart';
import 'package:thameeml_ansari_u_s_application3/widgets/app_bar/custom_app_bar.dart';
import 'package:thameeml_ansari_u_s_application3/widgets/custom_bottom_bar.dart';
import 'package:thameeml_ansari_u_s_application3/widgets/custom_icon_button.dart';
import 'provider/sound_provider.dart';

class SoundScreen extends StatefulWidget {
  const SoundScreen({Key? key})
      : super(
          key: key,
        );

  @override
  SoundScreenState createState() => SoundScreenState();
  static Widget builder(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => SoundProvider(),
      child: SoundScreen(),
    );
  }
}

class SoundScreenState extends State<SoundScreen> {
  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 25.h,
            vertical: 22.v,
          ),
          child: Column(
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  "msg_calming_playlist".tr,
                  style: theme.textTheme.headlineLarge,
                ),
              ),
              SizedBox(height: 20.v),
              CustomImageView(
                imagePath: ImageConstant.imgIllustration,
                height: 301.v,
                width: 300.h,
              ),
              SizedBox(height: 18.v),
              Text(
                "lbl_rain_on_glass".tr,
                style: theme.textTheme.displaySmall,
              ),
              Opacity(
                opacity: 0.5,
                child: Text(
                  "msg_by_painting_with".tr,
                  style: theme.textTheme.bodyLarge,
                ),
              ),
              SizedBox(height: 57.v),
              _buildEleven(context),
              SizedBox(height: 5.v),
            ],
          ),
        ),
        bottomNavigationBar: _buildBottomBar(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 49.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowDownPrimary,
        margin: EdgeInsets.only(
          left: 25.h,
          top: 16.v,
          bottom: 16.v,
        ),
      ),
      actions: [
        AppbarTrailingImage(
          imagePath: ImageConstant.imgPlaylistIcon,
          margin: EdgeInsets.symmetric(
            horizontal: 37.h,
            vertical: 16.v,
          ),
        ),
      ],
    );
  }

  /// Section Widget
  Widget _buildEleven(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 10.h),
      padding: EdgeInsets.symmetric(horizontal: 114.h),
      decoration: BoxDecoration(
        image: DecorationImage(
          image: fs.Svg(
            ImageConstant.imgGroup11,
          ),
          fit: BoxFit.cover,
        ),
      ),
      child: CustomIconButton(
        height: 75.adaptSize,
        width: 75.adaptSize,
        child: CustomImageView(),
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {},
    );
  }
}
