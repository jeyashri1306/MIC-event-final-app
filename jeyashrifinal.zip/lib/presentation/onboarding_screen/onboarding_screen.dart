import 'models/onboarding_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;
import 'package:thameeml_ansari_u_s_application3/core/app_export.dart';
import 'package:thameeml_ansari_u_s_application3/widgets/custom_elevated_button.dart';
import 'provider/onboarding_provider.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({Key? key}) : super(key: key);

  @override
  OnboardingScreenState createState() => OnboardingScreenState();

  static Widget builder(BuildContext context) {
    return ChangeNotifierProvider(
        create: (context) => OnboardingProvider(), child: OnboardingScreen());
  }
}

class OnboardingScreenState extends State<OnboardingScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 3000), () {
      NavigatorService.popAndPushNamed(
        AppRoutes.homeScreen,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: appTheme.indigo200,
            body: SizedBox(
                width: double.maxFinite,
                child: Column(children: [
                  SizedBox(height: 58.v),
                  Expanded(
                      child: SingleChildScrollView(
                          child: Padding(
                              padding: EdgeInsets.only(right: 25.h),
                              child: Column(children: [
                                Align(
                                    alignment: Alignment.centerRight,
                                    child: Container(
                                        width: 277.h,
                                        margin: EdgeInsets.only(
                                            left: 46.h, right: 26.h),
                                        child: Text("msg_it_s_ok_not_to_be".tr,
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.center,
                                            style: theme
                                                .textTheme.displayMedium))),
                                SizedBox(height: 33.v),
                                SizedBox(
                                    height: 768.v,
                                    width: 350.h,
                                    child: Stack(
                                        alignment: Alignment.centerRight,
                                        children: [
                                          Opacity(
                                              opacity: 0.4,
                                              child: CustomImageView(
                                                  imagePath:
                                                      ImageConstant.imgBgCircle,
                                                  height: 392.v,
                                                  width: 287.h,
                                                  alignment: Alignment.topLeft,
                                                  margin: EdgeInsets.only(
                                                      top: 32.v))),
                                          Align(
                                              alignment: Alignment.centerRight,
                                              child: Container(
                                                  padding: EdgeInsets.symmetric(
                                                      horizontal: 16.h,
                                                      vertical: 222.v),
                                                  decoration: BoxDecoration(
                                                      image: DecorationImage(
                                                          image: fs.Svg(
                                                              ImageConstant
                                                                  .imgGroup5),
                                                          fit: BoxFit.cover)),
                                                  child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment.end,
                                                      children: [
                                                        SizedBox(height: 254.v),
                                                        CustomElevatedButton(
                                                            text:
                                                                "lbl_let_us_help_you"
                                                                    .tr)
                                                      ])))
                                        ]))
                              ]))))
                ]))));
  }
}
