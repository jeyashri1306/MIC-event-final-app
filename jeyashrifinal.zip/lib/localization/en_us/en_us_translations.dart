final Map<String, String> enUs = {
  // Onboarding Screen
  "lbl_let_us_help_you": "Let Us Help You",
  "msg_it_s_ok_not_to_be": "It’s Ok Not To Be \nOKAY !!",

  // Home Screen
  "lbl": ", ",
  "lbl_06_00_pm": "06:00 PM",
  "lbl_calm": "Calm",
  "lbl_focus": "Focus",
  "lbl_happy": "Happy",
  "lbl_join_now": "Join Now",
  "lbl_meditation": "Meditation",
  "lbl_relax": "Relax",
  "lbl_sarina": "Sarina!",
  "lbl_today_s_task": "Today’s Task",
  "lbl_welcome_back": "Welcome back",
  "msg_aura_is_the_most":
      "Aura is the most important thing that matters to you.join us on ",
  "msg_how_are_you_feeling": "How are you feeling today ?",
  "msg_let_s_open_up_to":
      "Let’s open up to the  thing that matters amoung the people ",
  "msg_peer_group_meetup": "Peer Group Meetup",
  "msg_welcome_back_sarina": "Welcome back, Sarina!",

  // Sound Screen
  "lbl_rain_on_glass": "Rain On Glass",
  "msg_by_painting_with": "By: Painting with Passion",
  "msg_calming_playlist": "Calming  Playlist",

// Network Error String
  "msg_network_err": "Network Error",
  "msg_something_went_wrong": "Something Went Wrong!",
};
