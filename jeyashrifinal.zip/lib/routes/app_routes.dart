import 'package:flutter/material.dart';
import 'package:thameeml_ansari_u_s_application3/presentation/onboarding_screen/onboarding_screen.dart';
import 'package:thameeml_ansari_u_s_application3/presentation/home_screen/home_screen.dart';
import 'package:thameeml_ansari_u_s_application3/presentation/sound_screen/sound_screen.dart';
import 'package:thameeml_ansari_u_s_application3/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String onboardingScreen = '/onboarding_screen';

  static const String homeScreen = '/home_screen';

  static const String soundScreen = '/sound_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> get routes => {
        onboardingScreen: OnboardingScreen.builder,
        homeScreen: HomeScreen.builder,
        soundScreen: SoundScreen.builder,
        appNavigationScreen: AppNavigationScreen.builder,
        initialRoute: OnboardingScreen.builder
      };
}
