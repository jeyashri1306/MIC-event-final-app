class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Onboarding images
  static String imgBgCircle = '$imagePath/img_bg_circle.png';

  static String imgGroup5 = '$imagePath/img_group_5.svg';

  // Home images
  static String imgArrowDown = '$imagePath/img_arrow_down.svg';

  static String imgEllipse2 = '$imagePath/img_ellipse_2.png';

  static String imgThumbsUp = '$imagePath/img_thumbs_up.svg';

  static String imgUser = '$imagePath/img_user.svg';

  static String imgRelax = '$imagePath/img_relax.svg';

  static String imgVector = '$imagePath/img_vector.svg';

  static String imgVectorWhiteA700 = '$imagePath/img_vector_white_a700.svg';

  static String imgVectorPrimarycontainer =
      '$imagePath/img_vector_primarycontainer.svg';

  static String imgVectorPrimarycontainer15x15 =
      '$imagePath/img_vector_primarycontainer_15x15.svg';

  static String imgVectorPrimarycontainer41x36 =
      '$imagePath/img_vector_primarycontainer_41x36.svg';

  static String imgVectorPrimarycontainer24x40 =
      '$imagePath/img_vector_primarycontainer_24x40.svg';

  static String imgVector15x15 = '$imagePath/img_vector_15x15.svg';

  static String imgWarning = '$imagePath/img_warning.svg';

  static String imgVector1 = '$imagePath/img_vector_1.svg';

  static String imgFrame = '$imagePath/img_frame.svg';

  static String imgSettings = '$imagePath/img_settings.svg';

  static String imgIconsNavigation = '$imagePath/img_icons_navigation.svg';

  // Sound images
  static String imgArrowDownPrimary = '$imagePath/img_arrow_down_primary.svg';

  static String imgPlaylistIcon = '$imagePath/img_playlist_icon.svg';

  static String imgIllustration = '$imagePath/img_illustration.svg';

  static String imgGroup11 = '$imagePath/img_group_11.svg';

  static String imgNounHome2976614 = '$imagePath/img_noun_home_2976614.svg';

  static String imgVectorPrimary = '$imagePath/img_vector_primary.svg';

  static String imgNounUsers847316 = '$imagePath/img_noun_users_847316.svg';

  static String imgGroup2 = '$imagePath/img_group_2.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
